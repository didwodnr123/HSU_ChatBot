﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HSUbot.Details
{
    /// <summary>
    /// 메인 의도 담길 공간(상속으로 모두 의도를 저장함)
    /// </summary>
    public class MainDetail
    {
        public string intent { get; set; }
    }
}
