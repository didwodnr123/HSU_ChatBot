﻿using System;
namespace HSUbot.Details
{
    public class NoticeDetail : MainDetail
    {
        public string Case { get; set; }
    }
}