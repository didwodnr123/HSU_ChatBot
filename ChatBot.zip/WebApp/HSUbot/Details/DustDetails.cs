﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HSUbot.Details
{
    public class DustDetails : MainDetail
    {
        //public string Area { get; set; }
       // public string Service { get; set; }
       public string Dustservice { get; set; }
        public string Dosistationname { get; set; }
    }
}
