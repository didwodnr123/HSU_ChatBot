﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HSUbot.GraphDB
{
    /// <summary>
    /// 수행태도
    /// </summary>
    public class AbltAtt
    {
        public int AbltAttId { get; set; }
        public string Name { get; set; }
    }
}