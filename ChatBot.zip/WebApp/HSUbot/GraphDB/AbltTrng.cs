﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HSUbot.GraphDB
{
    /// <summary>
    /// 관련훈련 목록
    /// </summary>
    public class AbltTrng
    {
        public int AbltTrngId { get; set; }
        public string Name { get; set; }
    }
}
