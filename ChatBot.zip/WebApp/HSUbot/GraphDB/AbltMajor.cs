﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HSUbot.GraphDB
{
    /// <summary>
    /// 전공
    /// </summary>
    public class AbltMajor
    {
        public int AbltMajorId { get; set; }
        public string Name { get; set; }
    }
}
