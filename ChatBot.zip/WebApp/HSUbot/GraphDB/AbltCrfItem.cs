﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HSUbot.GraphDB
{
    /// <summary>
    /// 자격증
    /// </summary>
    public class AbltCrfItem
    {
        public int AbltCrfItemId { get; set; }
        public string Name { get; set; }
    }
}
