﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HSUbot.GraphDB
{
    /// <summary>
    /// 직무내용 목록
    /// </summary>
    public class AbltJobCont
    {
        public int AbltJobContId { get; set; }
        public string JobCont { get; set; }
    }
}
