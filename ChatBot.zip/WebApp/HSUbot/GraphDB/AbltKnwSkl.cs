﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HSUbot.GraphDB
{
    /// <summary>
    /// 지식 및 기술
    /// </summary>
    public class AbltKnwSkl
    {
        public int AbltKnwSklId { get; set; }
        public string Name { get; set; }
    }
}
